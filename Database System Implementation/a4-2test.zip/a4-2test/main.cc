#include "QueryPlanner.h"
using namespace std;

int main () {
    QueryPlanner qp;
    qp.Compile();
    qp.Print();
	return 0;
}
