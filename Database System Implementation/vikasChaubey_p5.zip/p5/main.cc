
#include "SQL.h"

/**
 * Entry point into the database
**/
int main()
{   SQL database;
    database.StartSQLDatabase();
    return 0;
}
