#ifndef FILE_H
#define FILE_H

#include "TwoWayList.h"
#include "Record.h"
#include "Schema.h"
#include "Comparison.h"
#include "ComparisonEngine.h"

class Record;
using namespace std;

/*
The second header file (File.h) contains the basic definitions of the Page and File classes. 

The Page class is the in-memory realization of a database page; a page is essentially
a collection of database records. The File class is a disk-based container class that
essentially holds an array of pages. 

Your DBFile will be built on top of the Page and File classes, so that when someone inserts
a bunch of records into your DBFile, your DBFile in turn will group those records into instances
of the Page class, and then store those instances of the Page class into an instance of the File class.
The details of how this grouping and storage are done will vary based upon the file type, but in the 
case of a simple heap file, you’ll want to have a single instance of the Page class stored within your DBFile
object to act as a one-page buffer. 

During a series of writes, after that instance of the Page class fills, you write its contents to disk using 
an instance of the File class that you’ll use to actually store the DBFile. During reads, you use that instance
of the Page class to read records from disk, one page at a time, and then return the records to the caller as 
they are requested. Of course, you’ll have to deal with the case when someone switches back and forth between 
reads and writes, in which case you may have to write this page to disk before it is full, assuming that it is dirty.

*/
class Page {
private:
	TwoWayList <Record> *myRecs;
	int numRecs;	
	int curSizeInBytes;

public:
	// constructor
	Page ();
	virtual ~Page ();

	// getter and setter method for page
	int getNumRecs();
	
	// this takes a page and writes its binary representation to bits
	void ToBinary (char *bits);

	// this takes a binary representation of a page and gets the
	// records from it
	void FromBinary (char *bits);

	// the deletes the first record from a page and returns it; returns
	// a zero if there were no records on the page
	int GetFirst (Record *firstOne);

	// this appends the record to the end of a page.  The return value
	// is a one on success and a aero if there is no more space
	// note that the record is consumed so it will have no value after
	int Append (Record *addMe);

	// empty it out
	void EmptyItOut ();

};


class File {
private:

	int myFilDes;
	off_t curLength; 

public:

	File ();
	~File ();

	// returns the current length of the file, in pages
	off_t GetLength ();

	// opens the given file; the first parameter tells whether or not to
	// create the file.  If the parameter is zero, a new file is created
	// the file; if notNew is zero, then the file is created and any other
	// file located at that location is erased.  Otherwise, the file is
	// simply opened
	void Open (int length, char *fName);

	// allows someone to explicitly get a specified page from the file
	void GetPage (Page *putItHere, off_t whichPage);

	// allows someone to explicitly write a specified page to the file
	// if the write is past the end of the file, all of the new pages that
	// are before the page to be written are zeroed out
	void AddPage (Page *addMe, off_t whichPage);

	// closes the file and returns the file length (in number of pages)
	int Close ();
    
    void MoveToFirst ();
    
    int IsFileOpen ();

};

#endif