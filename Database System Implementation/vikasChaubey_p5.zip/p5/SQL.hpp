//
//  SQL.hpp
//  dbindex
//
//  Created by Sathya Sairam on 28/04/20.
//  Copyright © 2020 Sathya Sairam. All rights reserved.
//

#ifndef SQL_hpp
#define SQL_hpp

#include <stdio.h>

#endif /* SQL_hpp */
