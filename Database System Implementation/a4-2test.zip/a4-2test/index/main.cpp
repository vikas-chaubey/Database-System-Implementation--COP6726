//
//  main.cpp
//  index
//
//  Created by Sathya Sairam on 21/04/20.
//  Copyright © 2020 Sathya Sairam. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
